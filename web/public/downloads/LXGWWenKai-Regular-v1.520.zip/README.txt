霞鹜文楷（LXGW WenKai）Regular v1.520

作者：LXGW；基于 The Klee Project Authors 的 Klee 字体。
项目：https://github.com/lxgw/LxgwWenKai
版本：https://github.com/lxgw/LxgwWenKai/releases/tag/v1.520
字体原文件：https://github.com/lxgw/LxgwWenKai/releases/download/v1.520/LXGWWenKai-Regular.ttf
许可证原文件：https://raw.githubusercontent.com/lxgw/LxgwWenKai/v1.520/OFL.txt

字体文件未经修改，按 SIL Open Font License 1.1 分发。
完整版权声明和许可条件见随包 OFL.txt。
字体 SHA-256：8d6ba638ac9553413354cfaab97637c1cd778444e259441ea1e5f8fb2c697fba

Pico Page 安装：解压后将 LXGWWenKai-Regular.ttf 和 OFL.txt 复制到 TF 卡的 Fonts/ 文件夹，在阅读工具的「排版」中选择该字体。
